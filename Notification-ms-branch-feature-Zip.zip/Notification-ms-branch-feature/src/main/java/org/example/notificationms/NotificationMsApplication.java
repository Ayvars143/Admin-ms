package org.example.notificationms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotificationMsApplication {

    public static void main(String[] args) {
        SpringApplication.run(NotificationMsApplication.class, args);
    }

}
